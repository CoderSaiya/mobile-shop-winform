﻿namespace MobileShop.UI.Forms.Views;

public partial class MemberForm : Form
{
    public MemberForm()
    {
        InitializeComponent();
    }
}